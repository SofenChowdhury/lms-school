<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row clearfix">
        <div class="col-lg-4 col-md-4">
            <div class="card profile-header">
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="body text-center">
                    <div class="profile-image mb-3"><img src="<?php echo e(asset('uploads/'.$key->teacher_photo)); ?>" style="width: 100%" class="rounded-circle" alt=""></div>
                    <div>
                        <h4 class="mb-0"><strong><?php echo e($key->teacher_name); ?></strong></h4>
                        <p><?php echo e($key->teacher_designation); ?></p>
                        <p style="margin-top: -12px;">#99999<?php echo e($key->teacher_id); ?></p>
                        <p><center><?php echo DNS1D::getBarcodeHTML($key->teacher_id, "C39",2,20,"#344857"); ?></center></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-lg-8 col-md-8">
            <div class="card">
                <div class="body">
                    <h1 style="font-family: cursive;">Teacher's Profile</h1>
                </div>
            </div>
            <div class="tab-content padding-0">
                <div class="tab-pane blog-page active" id="Profile">
                    <div class="row clearfix text-center">
                        <div class="col-lg-12 col-md-12">
                            <div class="card">
                                <div class="body">
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Date of Birth </span>:
                                        <?php echo e($key->teacher_birthday); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Joining Date </span>:
                                            <?php echo e($key->teacher_joining_date); ?></p>
                                         </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Gender </span>:
                                        <?php echo e($key->teacher_gender); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Blood Group </span>: <?php echo e($key->teacher_blood_group); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Religion </span>: <?php echo e($key->teacher_religion); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Email </span>: <?php echo e($key->teacher_email); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>ID Card </span>: <?php echo e($key->teacher_card_id); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Phone </span>: <?php echo e($key->teacher_phone); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>State </span>: <?php echo e($key->teacher_state); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Country </span>:
                                            <?php echo e($key->teacher_country); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p style="text-align:left"> <span>Address </span>: <?php echo e($key->teacher_address); ?></p>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="header">
                    <h2>Info</h2>
                </div>
                <div class="body">
                    <small class="text-muted">Address: </small>
                    <p style="text-align:left"> <?php echo e($key->teacher_address); ?></p>
                    <div>
                        <iframe width="100%" height="150" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.it/maps?q=<?php echo e($key->teacher_address); ?>&output=embed"></iframe>
                    </div>
                    <hr>
                    <small class="text-muted">Email address: </small>
                    <p style="text-align:left"> <?php echo e($key->teacher_email); ?></p>
                    <hr>
                    <small class="text-muted">Mobile: </small>
                    <p style="text-align:left"> <?php echo e($key->teacher_phone); ?></p>
                    <hr>
                    <small class="text-muted">Birth Date: </small>
                    <p class="m-b-0"><?php echo e($key->teacher_birthday); ?></p>
                    <hr>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.SMS-APP', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>