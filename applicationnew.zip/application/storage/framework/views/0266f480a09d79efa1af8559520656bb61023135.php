
<?php $__env->startSection('content'); ?>

        <div class="container-fluid">
           
            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                         <div class="header">
                            <div class="row">
                                <div class="col-lg-6" style="float: left;">
                                    <h2>Add <?php echo e($title); ?></h2>
                                </div>
                                <div class="col-lg-6" style="float: right;">
                                    <a href="<?php echo e(route('book_issue_students')); ?>" class="btn btn-primary  pull-right"><?php echo e($title); ?> List</a>
                                </div>
                            </div>
                            
                        </div>
                        <div class="body">
                             <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                             <form  method="post" action="<?php echo e(route('submitBooksIssueFrom')); ?>" validate enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    

                                    <div class="col-md-12">
                                       <div class="col-md-2">
                                            <p>Role* </p>
                                        </div>
                                        <div class="col-md-6">
                                            <select  name="role" id="usertype" class="form-control">
                                                <option value="">Select Member</option>        
                                                <option value="Teacher">Teacher</option>        
                                                <option value="Student">Student</option>        
                                            </select>
                                        </div>
                                    </div>
                                            <input type="hidden" name="check" id="check">
                                            
                                    <div class="col-md-12" id="TeacherID">
                                       <div class="col-md-2">
                                            <p>Name* </p>
                                        </div>
                                        <div class="col-md-6" >
                                            <select  name="teacher_id" class="form-control">
                                                <option value="">Select Member</option>
                                            <?php $__currentLoopData = $manage_teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($teacher->user_id); ?>"><?php echo e($teacher->teacher_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12" id="StudentID">
                                       <div class="col-md-2">
                                            <p>Name* </p>
                                        </div>
                                        <div class="col-md-6" >
                                            <select  name="student_id" class="form-control">
                                                <option value="">Select Member</option>
                                            <?php $__currentLoopData = $manage_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($student->user_id); ?>"><?php echo e($student->student_name); ?>, <span> Class: <?php echo e($student->class_name); ?>,</span> <span> Section: <?php echo e($student->section_name); ?>,</span><span> Roll: <?php echo e($student->student_roll_no); ?></span></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                       <div class="col-md-2">
                                            <p>Book Name* </p>
                                        </div>
                                        <div class="col-md-6">
                                            <select  name="book_id" class="form-control">
                                                <option value="">Select Class</option>
                                                <?php $__currentLoopData = $manage_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $books): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($books->book_id); ?>"><?php echo e($books->book_name); ?>, <?php echo e($books->serial_id); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <!-- <div class="col-md-12">
                                       <div class="col-md-2">
                                            <p>Category* </p>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" name="section_category" class="form-control" >
                                        </div>
                                    </div> -->

                                    <div class="col-md-12">
                                       <div class="col-md-2">
                                            <p>Due Date* </p>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="date" name="due_date" class="form-control" >
                                        </div>
                                    </div>

                                    <!-- <div class="col-md-12">
                                       <div class="col-md-2">
                                            <p>Note </p>
                                        </div>
                                        <div class="col-md-6">
                                            <textarea type="text" name="note" class="form-control"></textarea>
                                        </div>
                                    </div> -->
                                </div>
                                <br>
                                <div class="col-md-12">
                                    <div class="col-md-2">
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-primary">Issu Book</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            
            </div>
            
        </div>

<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous">
</script>
<script>  
            $('#StudentID').hide();   
            $('#TeacherID').hide();   
            $('#usertype').change(function(){
                var usertype = $('#usertype option:selected').val();

                if(usertype == 'Teacher'){
                     $('#StudentID').hide();    
                     $('#TeacherID').show();
                     $('#check').val("teacher");    
                }else{
                    $('#TeacherID').hide();
                    $('#StudentID').show();
                    $('#check').val("student");
                }

              });  
     
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.SMS-APP', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>