
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <div class="row">
                        <div class="col-lg-6" style="float: left;">
                            <h2><?php echo e($title); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="body">
                    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <form id="basic-form" action="<?php echo e(route('showTransectionreport')); ?>" method="post" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-4">
                                    <label>Start Date *</label>
                                    <input type="date" class="form-control" name="start_date">
                                </div>
                                <div class="col-md-4">
                                    <label>End Date *</label>
                                    <input type="date" class="form-control" name="end_date">
                                </div>
                                <!-- <div class="col-md-3">
                                    <label>Student *</label>
                                    <select  name="student_id" id="student_id" class="form-control">
                                        <option value="">Select Student</option>
                                    </select>
                                </div> -->
                                <div class="col-md-4 pull-right">
                                    <label> </label><br>
                                    <button type="submit" class="btn btn-primary btn-block m-t-10 pull-right">Show</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.SMS-APP', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>