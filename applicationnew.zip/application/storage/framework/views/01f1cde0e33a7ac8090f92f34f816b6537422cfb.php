
<?php $__env->startSection('content'); ?>

            <!-- Slider Start --> 
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="background-image: url('<?php echo e(asset('uploads').'/'.$key->banner); ?>'); background-attachment: fixed; background-size: cover;" class="page-section">
                    <div style="background:rgb(49,49,49,0.5); padding:200px 0 50px;">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="cs-page-title">
                                        <h1 style="color: white !important; font-weight: bold;"><?php echo e($title); ?></h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Main Start -->
            <div class="main-section"> 
                <!--Page Section Wide With Right SideBar-->
                <div class="page-section" style=" padding-top:10px; padding-bottom:50px;">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                <?php $__currentLoopData = $academic_calender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h2><?php echo e($key->title); ?></h2> 
                                    <p><?php echo $key->description; ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <aside class="section-sidebar col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <h4 class="quick-navigation">Quick Navigation</h4>
                                <div class="widget cs-widget-links">
                                    <ul>
                                        <li><a class="<?php echo e(request()->is('dress-code') ? 'ctg_active ' : ''); ?>" href="<?php echo e(route('dress-code-page')); ?>">Dress Code</a></li>
                                        <li><a class="<?php echo e(request()->is('academic-calendar') ? 'ctg_active ' : ''); ?>" href="<?php echo e(route('academic-calendar-page')); ?>">Academic Calendar</a></li>
                                        <li><a class="<?php echo e(request()->is('book-list-and-syllabust') ? 'ctg_active ' : ''); ?>" href="<?php echo e(route('book-list-and-syllabus-page')); ?>">Book List & Syllabus</a></li>
                                        <li><a class="<?php echo e(request()->is('class-routine') ? 'ctg_active ' : ''); ?>" href="<?php echo e(route('class-routine-page')); ?>">Class Routine</a></li>
                                        <li><a class="<?php echo e(request()->is('exam-routine') ? 'ctg_active ' : ''); ?>" href="<?php echo e(route('exam-routine-page')); ?>">Exam Routine</a></li>
                                        <li><a class="<?php echo e(request()->is('teachers-and-staffs') ? 'ctg_active ' : ''); ?>" href="<?php echo e(route('teachers-and-staffs-page')); ?>">Teachers and Staffs</a></li>
                                    </ul>              
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Main End --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.WEB-APP', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>