<?php $__env->startSection('content'); ?>

        <div class="container-fluid">            
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <div class="row">
                                <div class="col-lg-6" style="float: left;">
                                    <h2><?php echo e($title); ?></h2>
                                </div>
                                <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'SUPPERADMIN'): ?>
                                <div class="col-lg-6" style="float: right;">
                                    <a href="<?php echo e(route('add-assignment')); ?>" class="btn btn-primary  pull-right">Add <?php echo e($title); ?></a>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                        </div>
                        <div class="body">
                            <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <div class="table-responsive">
                                <table id="tableid" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Class</th>
                                            <th>Section</th>
                                            <th>File</th>
                                            <th>Deadline</th>
                                            <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'SUPPERADMIN'): ?>
                                            <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $manage_assignment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index+1); ?></td>
                                            <td><?php echo e($assignment->assignment_title); ?></td>
                                            <td><?php echo e(substr($assignment->assignment_description,0,50)); ?>....</td>
                                            <td><?php echo e($assignment->class_name); ?></td>
                                            <td><?php echo e($assignment->section_name); ?></td>
                                            <td><a href="<?php echo e(asset('uploads').'/'.$assignment->assignment_file); ?>" style="color: #b30451; text-align: center; font-size: 20px;" target="_blank"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></td>
                                            <td><?php echo e($assignment->assignment_deadline); ?></td>
                                            <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'SUPPERADMIN'): ?>
                                            <td class="actions">                          
                                                <a href="<?php echo e(route('view_assignment',['id'=>$assignment->assignment_id])); ?>"><button class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit"
                                                data-toggle="tooltip" data-original-title="View"><i class="icon-eye" aria-hidden="true"></i></button></a>
                                                <a href="<?php echo e(route('edit_assignment',['id'=>$assignment->assignment_id])); ?>"><button class="btn btn-sm btn-icon btn-pure btn-default on-default m-r-5 button-edit"
                                                data-toggle="tooltip" data-original-title="Edit"><i class="icon-pencil" aria-hidden="true"></i></button></a>
                                                <?php if(Auth::user()->role == 'SUPPERADMIN'): ?>
                                                <a href="<?php echo e(route('delete_assignment',['id'=>$assignment->assignment_id])); ?>" id="delete"><button class="btn btn-sm btn-icon btn-pure btn-default on-default button-remove"
                                                data-toggle="tooltip" data-original-title="Remove"><i class="icon-trash" aria-hidden="true"></i></button></a>
                                                <?php endif; ?>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>  
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.SMS-APP', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>