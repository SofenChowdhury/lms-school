<?php $__env->startSection('content'); ?>

        <div class="container-fluid">            
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <div class="row">
                                <div class="col-lg-6" style="float: left;">
                                    <h2><?php echo e($title); ?></h2>
                                </div>
                                <!-- <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'SUPPERADMIN'): ?>
                                <div class="col-lg-6" style="float: right;">
                                    <a href="<?php echo e(route('add-assignment')); ?>" class="btn btn-primary  pull-right">Add <?php echo e($title); ?></a>
                                </div>
                                <?php endif; ?> -->
                            </div>
                            
                        </div>
                        <div class="body">
                            <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <div class="table-responsive">
                                <form action="<?php echo e(route('save_promotionForm')); ?>"  method="post">
                                    <?php echo csrf_field(); ?>

                                    <table class="" style="margin-bottom: 40px;">
                                        <tr>
                                            <th>Promoted Class</th>
                                            <th>:</th>
                                            <td>
                                                <select  name="promoted_class" class="form-control" style="width: 300px;">
                                                    
                                                    <option value="<?php echo e($student_class_id); ?>"> <?php echo e($class_name); ?></option>
                                                    <?php $__currentLoopData = $manage_class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key->class_id); ?>"><?php echo e($key->class_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                    </table> 

                                    <table id="" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Photo</th>
                                                <th>Name</th>
                                                <th>Roll</th>
                                                <th>Total Marks</th>
                                                <?php if(Auth::user()->role == 'Admin' || Auth::user()->role == 'SUPPERADMIN'): ?>
                                                <th>Action</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $show_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->index+1); ?></td>
                                                <td><img src="<?php echo e(asset('uploads').'/'.$student->student_photo); ?>" style="width: 80px; height: 80px;"></td>
                                                <td><?php echo e($student->student_name); ?> <input type="hidden" name="up_student" value="<?php echo e(date('y-m-d h:i:s')); ?>"></td>

                                                <td><?php echo e($student->student_roll_no); ?></td>

                                                <?php

                                                    $sum_mcq = DB::table('exam_marks')
                                                                ->where('student_id',$student->student_id)
                                                                ->sum('mcq_marks');

                                                    $sum_theory = DB::table('exam_marks')
                                                                ->where('student_id',$student->student_id)
                                                                ->sum('theory_marks');

                                                    $total_marks = $sum_mcq + $sum_theory;       

                                                ?>

                                                <td><?php echo e($total_marks); ?></td>   
                                                <td>
                                                    <input type="checkbox" class="btn present" value="<?php echo e($student->student_id); ?>" name="student_id[]">
                                                    <label style="vertical-align:  middle;display: inline;">Promoted </label>           
                                                </td> 
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <button type="submit" style="margin-top: 20px;" class="btn btn-success pull-right save_attendance">Submit
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.SMS-APP', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>