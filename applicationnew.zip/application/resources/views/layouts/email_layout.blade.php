<div>
	Hi, This is : {{ $data['name'] }}
</div>