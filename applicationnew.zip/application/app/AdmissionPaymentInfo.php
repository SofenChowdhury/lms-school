<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdmissionPaymentInfo extends Model
{
    //
    use SoftDeletes;
}
