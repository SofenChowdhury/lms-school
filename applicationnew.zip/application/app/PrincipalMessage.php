<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PrincipalMessage extends Model
{
    //
    use SoftDeletes;
}
