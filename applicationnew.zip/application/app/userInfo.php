<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class userInfo extends Model
{
    //
	use SoftDeletes;
}
